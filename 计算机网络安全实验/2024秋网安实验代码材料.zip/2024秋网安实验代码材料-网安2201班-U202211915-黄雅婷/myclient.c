#include <arpa/inet.h>
#include <fcntl.h>
#include <linux/if.h>
#include <linux/if_tun.h>
#include <netdb.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <pthread.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

// 定义错误检查宏，用于检查SSL操作是否成功
#define CHK_SSL(err)                     \
    do                                   \
    {                                    \
        if ((err) < 1)                   \
        {                                \
            ERR_print_errors_fp(stderr); \
            exit(2);                     \
        }                                \
    } while (0)
// 定义CA证书目录
#define CA_DIR "./ca_client"

// 证书验证回调函数
int verify_callback(int preverify_ok, X509_STORE_CTX *x509_ctx)
{
    char buf[300];

    // 获取当前证书
    X509 *cert = X509_STORE_CTX_get_current_cert(x509_ctx);
    // 获取证书主题
    X509_NAME_oneline(X509_get_subject_name(cert), buf, 300);
    printf("证书主题：%s\n", buf);

    // 打印验证结果
    if (preverify_ok == 1)
    {
        printf("验证通过。\n");
    }
    else
    {
        // 获取验证错误代码
        int err = X509_STORE_CTX_get_error(x509_ctx);
        printf("错误：验证失败：%s。\n", X509_verify_cert_error_string(err));
    }

    // 返回验证结果
    return preverify_ok;
}

// 初始化TLS客户端
SSL *setupTLSClient(const char *hostname)
{
    // 初始化SSL库
    SSL_library_init();
    // 加载SSL错误字符串
    SSL_load_error_strings();
    // 添加SSL算法
    SSLeay_add_ssl_algorithms();
    SSL_METHOD *method;
    SSL_CTX *context;
    SSL *ssl;
    // 获取TLSv1.2方法
    method = (SSL_METHOD *)TLSv1_2_method();
    // 创建SSL上下文
    context = SSL_CTX_new(method);

    // 设置证书验证模式和回调函数
    SSL_CTX_set_verify(context, SSL_VERIFY_PEER, verify_callback);
    // 加载CA证书
    if (SSL_CTX_load_verify_locations(context, NULL, CA_DIR) < 1)
    {
        printf("错误：设置验证位置失败。\n");
        exit(0);
    }
    // 创建SSL对象
    ssl = SSL_new(context);

    // 设置主机名验证参数
    X509_VERIFY_PARAM *vpm = SSL_get0_param(ssl);
    X509_VERIFY_PARAM_set1_host(vpm, hostname, 0);

    return ssl;
}

// 设置TCP客户端
int setupTCPClient(const char *hostname, int port)
{
    struct sockaddr_in server_addr;
    struct hostent *hp = gethostbyname(hostname);
    int sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    // 初始化服务器地址结构
    memset(&server_addr, 0, sizeof(server_addr));
    // 复制主机地址
    memcpy(&(server_addr.sin_addr.s_addr), hp->h_addr, hp->h_length);
    server_addr.sin_port = htons(port);
    server_addr.sin_family = AF_INET;
    // 连接到服务器
    connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr));

    return sockfd;
}

// 创建TUN设备
int createTunDevice()
{
    int tunfd;
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));

    // 设置TUN设备标志
    ifr.ifr_flags = IFF_TUN | IFF_NO_PI;
    // 打开TUN设备文件
    tunfd = open("/dev/net/tun", O_RDWR);
    // 设置TUN设备接口
    ioctl(tunfd, TUNSETIFF, &ifr);

    return tunfd;
}

// 线程数据结构
typedef struct thread_data
{
    int tunfd;
    SSL *ssl;
} THDATA, *PTHDATA;

char *last_ip;

// 监听TUN设备
void *listen_tun(void *threadData)
{
    PTHDATA ptd = (PTHDATA)threadData;
    char buff[2000];

    while (1)
    {
        // 从TUN设备读取数据
        int len = read(ptd->tunfd, buff, sizeof(buff));
        if (len > 19 && buff[0] == 0x45)
        {
            // 检查IP地址是否匹配
            if ((int)buff[15] == atoi(last_ip))
            {
                printf("接收到TUN数据：%d\n", len);
                // 将数据写入SSL连接
                SSL_write(ptd->ssl, buff, len);
            }
            else
            {
                printf("错误：IP不正确：192.168.53.%s\n", last_ip);
            }
        }
    }
}

int main(int argc, char *argv[])
{
    // 检查命令行参数
    if (argc < 6)
    {
        printf("错误：缺少参数。使用方法：./myclient <hostname> <port> <username> <password> <last_ip>\n");
        exit(1);
    }

    char *hostname = argv[1];
    int port = atoi(argv[2]);
    char *username = argv[3];
    char *password = argv[4];
    last_ip = argv[5];

    // 初始化TLS客户端
    SSL *ssl = setupTLSClient(hostname);
    printf("TLS客户端设置成功！\n");

    // 设置TCP客户端
    int sockfd = setupTCPClient(hostname, port);
    printf("TCP客户端设置成功！\n");

    // 设置SSL套接字
    SSL_set_fd(ssl, sockfd);
    // 建立SSL连接
    int err = SSL_connect(ssl);
    CHK_SSL(err);
    printf("SSL连接成功！\n");
    printf("SSL连接使用：%s\n", SSL_get_cipher(ssl));

    // 发送用户名、密码和本地IP的最后一个字节
    SSL_write(ssl, username, strlen(username));
    SSL_write(ssl, password, strlen(password));
    SSL_write(ssl, last_ip, strlen(last_ip));

    // 创建TUN设备
    int tunfd = createTunDevice();
    pthread_t listen_tun_thread;
    THDATA threadData = {tunfd, ssl};
    // 创建监听TUN设备的线程
    pthread_create(&listen_tun_thread, NULL, listen_tun, (void *)&threadData);

    // 配置TUN设备和路由
    char cmd[100];
    snprintf(cmd, sizeof(cmd), "sudo ifconfig tun0 192.168.53.%s/24 up && sudo route add -net 192.168.60.0/24 tun0", last_ip);
    system(cmd);

    char buf[9000];
    int len;
    // 从SSL连接读取数据并写入TUN设备
    while ((len = SSL_read(ssl, buf, sizeof(buf) - 1)) > 0)
    {
        write(tunfd, buf, len);
        printf("SSL接收到数据：%d\n", len);
    }
    // 取消监听TUN设备的线程
    pthread_cancel(listen_tun_thread);
    printf("连接已关闭！\n");

    // 关闭SSL连接
    SSL_shutdown(ssl);
    SSL_free(ssl);
    close(sockfd);
    close(tunfd);

    return 0;
}