#include <arpa/inet.h>
#include <crypt.h>
#include <fcntl.h>
#include <linux/if.h>
#include <linux/if_tun.h>
#include <netdb.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <pthread.h>
#include <shadow.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

// 定义错误检查宏，用于检查SSL操作是否成功
#define CHK_SSL(err)                     \
    do {                                 \
        if ((err) < 1) {                 \
            ERR_print_errors_fp(stderr); \
            exit(2);                     \
        }                                \
    } while (0)
// 定义错误检查宏，用于检查系统调用是否成功
#define CHK_ERR(err, s) \
    if ((err) == -1) {  \
        perror(s);      \
        exit(1);        \
    }

// 初始化TLS服务器
SSL *setupTLSServer() {
    SSL_METHOD *meth;
    SSL_CTX *ctx;
    SSL *ssl;   

    // 初始化SSL库
    SSL_library_init();
    // 加载SSL错误字符串
    SSL_load_error_strings();
    // 添加SSL算法
    SSLeay_add_ssl_algorithms();
    // 获取TLSv1.2方法
    meth = (SSL_METHOD *)TLSv1_2_method();
    // 创建SSL上下文
    ctx = SSL_CTX_new(meth);
 
    // 设置SSL验证模式为不验证
    SSL_CTX_set_verify(ctx, SSL_VERIFY_NONE, NULL);
    // 加载服务器证书
    SSL_CTX_use_certificate_file(ctx, "./cert/server-hyt.crt", SSL_FILETYPE_PEM);
    // 加载服务器私钥
    SSL_CTX_use_PrivateKey_file(ctx, "./cert/server-hyt.key", SSL_FILETYPE_PEM);
    // 创建SSL对象
    ssl = SSL_new(ctx);
    
    return ssl;
}

// 设置TCP服务器
int setupTCPServer() {
    struct sockaddr_in sa_server;
    int listen_sock;

    // 创建TCP套接字
    listen_sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP);
    CHK_ERR(listen_sock, "socket");
    // 初始化服务器地址结构
    memset(&sa_server, '\0', sizeof(sa_server));
    sa_server.sin_family = AF_INET;
    sa_server.sin_addr.s_addr = INADDR_ANY;
    sa_server.sin_port = htons(4433);
    // 绑定套接字到地址
    int err = bind(listen_sock, (struct sockaddr *)&sa_server, sizeof(sa_server));
    CHK_ERR(err, "bind");
    // 监听套接字
    err = listen(listen_sock, 5);
    CHK_ERR(err, "listen");
    return listen_sock;
}

// 创建TUN设备
int createTunDevice() {
    int tunfd;
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(ifr));

    // 设置TUN设备标志
    ifr.ifr_flags = IFF_TUN | IFF_NO_PI;

    // 打开TUN设备文件
    tunfd = open("/dev/net/tun", O_RDWR);
    // 设置TUN设备接口
    ioctl(tunfd, TUNSETIFF, &ifr);

    return tunfd;
}

// 管道数据结构
typedef struct pipe_data {
    char *pipe_file;
    SSL *ssl;
} PIPEDATA;

// 监听TUN设备
void *listen_tun(void *tunfd) {
    int fd = *((int *)tunfd);
    char buff[2000];
    while (1) {
        // 从TUN设备读取数据
        int len = read(fd, buff, 2000);
        if (len > 19 && buff[0] == 0x45) {
            // 打印接收到的数据信息
            printf("TUN接收到数据，长度：%d，目标IP：192.168.53.%d\n", len, (int)buff[19]);
            char pipe_file[10];
            // 生成管道文件名
            sprintf(pipe_file, "./pipe/%d", (int)buff[19]);
            int fd = open(pipe_file, O_WRONLY);
            if (fd == -1) {
                // 如果管道文件不存在，打印警告
                printf("[警告] 文件 %s 不存在。\n", pipe_file);
            } else {
                // 将数据写入管道文件
                write(fd, buff, len);
            }
        }
    }
}

// 用户登录验证
int login(char *user, char *passwd) {
    struct spwd *pw;
    char *epasswd; 
    // 获取用户密码信息
    pw = getspnam(user);
    if (pw == NULL) {
        // 如果用户不存在，打印错误信息
        printf("错误：密码为空。\n");
        return 0;
    }

    // 打印用户名和密码
    printf("用户名：%s\n", pw->sp_namp);
    printf("密码：%s\n", pw->sp_pwdp);

    // 加密密码
    epasswd = crypt(passwd, pw->sp_pwdp);
    // 比较加密后的密码和存储的密码
    if (strcmp(epasswd, pw->sp_pwdp)) {
        // 如果密码不匹配，打印错误信息
        printf("错误：密码错误！\n");
        return 0;
    }
    return 1;
}

// 监听管道文件
void *listen_pipe(void *threadData) {
    PIPEDATA *ptd = (PIPEDATA*)threadData;
    int pipefd = open(ptd->pipe_file, O_RDONLY);

    char buff[2000];
    int len;
    // 从管道文件读取数据并写入SSL连接
    do {
        len = read(pipefd, buff, 2000);
        SSL_write(ptd->ssl, buff, len);
    } while (len > 0);
    // 打印读取完成信息并删除管道文件
    printf("%s 读取到0字节。连接已关闭，文件已删除。\n", ptd->pipe_file);
    remove(ptd->pipe_file);
}

// 处理SSL数据
void sendOut(SSL *ssl, int sock, int tunfd) {
    int len;
    // 从SSL连接读取数据并写入TUN设备
    do {
        char buf[1024];
        len = SSL_read(ssl, buf, sizeof(buf) - 1);
        write(tunfd, buf, len);
        buf[len] = '\0';
        printf("SSL接收到数据：%d\n", len);
    } while (len > 0);
    printf("SSL连接已关闭。\n");
}

int main() {
    int err;
    struct sockaddr_in sa_client;
    size_t client_len = sizeof(sa_client);
    // 初始化TLS服务器
    SSL *ssl = setupTLSServer();
    // 设置TCP服务器
    int listen_sock = setupTCPServer();
    // 创建TUN设备
    int tunfd = createTunDevice();
    // 配置TUN设备和IP转发
    system("sudo ifconfig tun0 192.168.53.1/24 up && sudo sysctl net.ipv4.ip_forward=1");
    // 删除旧的管道目录并创建新的管道目录
    system("rm -rf pipe");
    mkdir("pipe", 0666);
    pthread_t listen_tun_thread;
    // 创建监听TUN设备的线程
    pthread_create(&listen_tun_thread, NULL, listen_tun, (void *)&tunfd);

    while (1) {
        // 接受客户端连接
        int sock = accept(listen_sock, (struct sockaddr *)&sa_client, &client_len);
        if (fork() == 0) {
            // 子进程处理客户端连接
            close(listen_sock);
            // 设置SSL套接字
            SSL_set_fd(ssl, sock);
            // 接受SSL连接
            int err = SSL_accept(ssl);
            CHK_SSL(err);
            printf("SSL连接已建立！\n");
            char user[1024], passwd[1024], last_ip_buff[1024];
            // 读取客户端发送的用户名、密码和IP地址
            user[SSL_read(ssl, user, sizeof(user) - 1)] = '\0';
            passwd[SSL_read(ssl, passwd, sizeof(passwd) - 1)] = '\0';
            last_ip_buff[SSL_read(ssl, last_ip_buff, sizeof(last_ip_buff) - 1)] = '\0';

            // 验证用户登录
            if (login(user, passwd)) {
                printf("登录成功！\n");
                char pipe_file[10];
                // 生成管道文件名
                sprintf(pipe_file, "./pipe/%s", last_ip_buff);
                // 创建管道文件
                if (mkfifo(pipe_file, 0666) == -1) {
                    printf("警告：此IP(%s)已被占用。\n", last_ip_buff);
                } else {
                    pthread_t listen_pipe_thread;
                    PIPEDATA pipeData;
                    pipeData.pipe_file = pipe_file;
                    pipeData.ssl = ssl;
                    // 创建监听管道文件的线程
                    pthread_create(&listen_pipe_thread, NULL, listen_pipe, (void *)&pipeData);
                    // 处理SSL数据
                    sendOut(ssl, sock, tunfd);
                    // 取消监听管道文件的线程
                    pthread_cancel(listen_pipe_thread);
                    // 删除管道文件
                    remove(pipe_file);
                }
            } else {
                printf("错误：登录失败！\n");
            }
            // 关闭SSL连接
            SSL_shutdown(ssl);
            SSL_free(ssl);
            close(sock);
            printf("套接字已关闭！\n");
            return 0;
        } else {
            // 父进程关闭客户端套接字
            close(sock);
        }
    }
}